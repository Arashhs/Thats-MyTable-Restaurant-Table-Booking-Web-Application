create definer = root@localhost trigger check_freelink
    before insert
    on free_service
    for each row
BEGIN
  IF (exists (select * from vip_service_archieve as vs where vs.shortURL = NEW.shortURL) OR EXISTS(select * from vip_service as vp where vp.shortURL = NEW.shortURL)) THEN -- Abort when trying to remove this record
      	CALL shortURL_already_used; -- raise an error to prevent deleting from the table
  END IF;
END;

