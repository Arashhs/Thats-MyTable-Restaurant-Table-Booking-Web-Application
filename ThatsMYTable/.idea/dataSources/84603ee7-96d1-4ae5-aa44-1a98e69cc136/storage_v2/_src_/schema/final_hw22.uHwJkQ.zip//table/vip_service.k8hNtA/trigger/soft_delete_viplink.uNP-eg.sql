create definer = root@localhost trigger soft_delete_viplink
    before delete
    on vip_service
    for each row
BEGIN
    INSERT INTO vip_service_archieve VALUES(old.URL, old.shortURL, old.creation_time, old.IR_access, old.foreign_access, old.expiration_date, NOW());
END;

