create definer = root@localhost trigger check_vipshortlink
    before insert
    on vip_service
    for each row
BEGIN
  IF exists (select * from vip_service_archieve as vs where vs.shortURL = NEW.shortURL) THEN -- Abort when trying to remove this record
      	CALL shortURL_already_used; -- raise an error to prevent deleting from the table
  END IF;
END;

